package io.javabrains.moviedataservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieDataServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
